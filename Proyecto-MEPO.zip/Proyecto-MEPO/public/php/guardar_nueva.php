<?php

$servidor = "localhost";
$usuario = "root";
$clave = "";
$basededatos = "mepo";

$enlace = mysqli_connect($servidor,$usuario,$clave,$basededatos);

if(isset($_GET['token'])){
    $token = mysqli_real_escape_string($enlace,$_GET['token']);
}else{
    die("Token inválido");
}

/* VERIFICAR TOKEN */
$sql = "SELECT * FROM usuario 
        WHERE token='$token' 
        AND token_expira > NOW()";

$resultado = mysqli_query($enlace,$sql);

if(mysqli_num_rows($resultado) == 0){
    die("El enlace no es válido o ya expiró.");
}

if(isset($_POST['nueva_pass'])){

    if(strlen($_POST['nueva_pass']) < 6){
        die("La contraseña debe tener mínimo 6 caracteres");
    }

    $nueva = sha1($_POST['nueva_pass']);

    $sql = "UPDATE usuario 
            SET contrasena='$nueva',
                token=NULL,
                token_expira=NULL
            WHERE token='$token'";

    mysqli_query($enlace, $sql);
?>

<div id="successMsg" style="
position: fixed;
top: 20px;
right: 20px;
background: #28a745;
color: white;
padding: 15px 20px;
border-radius: 8px;
font-weight: bold;
z-index: 9999;">
✔ Contraseña actualizada correctamente
</div>

<script>
setTimeout(()=>{
    window.location.href="../php/login.php";
},3000);
</script>

<?php
exit();
}
?>

<form method="POST">

<input type="password" name="nueva_pass" placeholder="Nueva contraseña" required>

<button type="submit">Cambiar contraseña</button>

</form>
