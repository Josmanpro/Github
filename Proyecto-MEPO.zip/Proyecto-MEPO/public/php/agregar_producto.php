<?php
$conn = new mysqli("localhost", "root", "", "mepo");

if($_POST){
    $nombre = $_POST['nombre'];
    $precio = $_POST['precio'];
    $imagen = $_FILES['imagen']['name'];

    $nombreImagen = $_FILES['imagen']['name'];
    $ruta = "../imagenes/" . $nombreImagen;

    move_uploaded_file($_FILES['imagen']['tmp_name'], $ruta);

    $sql = "INSERT INTO productos (nombre, precio, imagen)
            VALUES ('$nombre','$precio','$nombreImagen')";
    $conn->query($sql);

    header("Location: panel_vendedor.php");
}
?>

<form method="POST" enctype="multipart/form-data">
    Nombre: <input type="text" name="nombre" required><br>
    Precio: <input type="number" step="0.01" name="precio"><br>
    Imagen: <input type="file" name="imagen"><br>
    <button type="submit">Guardar</button>
</form>