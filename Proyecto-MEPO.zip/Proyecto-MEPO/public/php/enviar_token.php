<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

$servidor = "localhost";
$usuario = "root";
$clave = "";
$basededatos = "mepo";

$enlace = mysqli_connect($servidor,$usuario,$clave,$basededatos);

if(!$enlace){
    die("Error de conexión: " . mysqli_connect_error());
}

if(isset($_POST['recoverEmail'])){

    $correo_tel = mysqli_real_escape_string($enlace, $_POST['recoverEmail']);

    // VALIDAR QUE SEA UN CORREO
    if(!filter_var($correo_tel, FILTER_VALIDATE_EMAIL)){
        die("Debe ingresar un correo válido");
    }

    // BUSCAR USUARIO
    $sql = "SELECT * FROM usuario WHERE correo_tel='$correo_tel'";
    $resultado = mysqli_query($enlace, $sql);

    if(mysqli_num_rows($resultado) > 0){

        // GENERAR TOKEN ÚNICO
        do{
            $token = bin2hex(random_bytes(16));
            $check = mysqli_query($enlace, "SELECT token FROM usuario WHERE token='$token'");
        }while(mysqli_num_rows($check) > 0);

        // EXPIRACIÓN DEL TOKEN
        $expira = date("Y-m-d H:i:s", strtotime("+1 hour"));

        // GUARDAR TOKEN
        $update = "UPDATE usuario 
                   SET token='$token', token_expira='$expira'
                   WHERE correo_tel='$correo_tel'";

        if(!mysqli_query($enlace, $update)){
            die("Error al guardar el token");
        }

        // LINK DE RECUPERACIÓN
        $enlace_recuperacion = "http://localhost/Github/Proyecto-MEPO/public/php/guardar_nueva.php?token=$token";

        $mail = new PHPMailer(true);

        try{

            // CONFIGURACIÓN SMTP
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'josephalfonsoforero@gmail.com';
            $mail->Password   = 'yiwv hpvc sdnv bcqx';
            $mail->SMTPSecure = 'tls';
            $mail->Port       = 587;

            // CONFIGURACIÓN DEL CORREO
            $mail->setFrom('josephalfonsoforero@gmail.com', 'MEPO');
            $mail->addAddress($correo_tel);

            $mail->isHTML(true);
            $mail->Subject = 'Recuperación de contraseña - MEPO';

            $mail->Body = "
            <h2>Recuperación de contraseña</h2>

            <p>Hola, solicitaste recuperar tu contraseña.</p>

            <p>Haz clic en el siguiente enlace para crear una nueva contraseña:</p>

            <a href='$enlace_recuperacion'>
            $enlace_recuperacion
            </a>

            <p>Este enlace expirará en <b>1 hora</b>.</p>

            <br>

            <p>Si no solicitaste este cambio, ignora este mensaje.</p>
            ";

            $mail->send();

            echo "Correo de recuperación enviado correctamente.";

        }catch(Exception $e){

            echo "Error al enviar el correo: {$mail->ErrorInfo}";

        }

    }else{

        echo "El correo no existe en el sistema.";

    }
}

?>